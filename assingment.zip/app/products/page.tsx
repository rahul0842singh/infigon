import { AppShell } from "@/components/AppShell";
import { ProductExplorer } from "@/components/ProductExplorer";
import { getProducts } from "@/lib/api";

export default async function ProductsPage() {
  const products = await getProducts();

  return (
    <AppShell title="Product Explorer" subtitle="Filter • Favorites • Details">
      <ProductExplorer products={products} />
    </AppShell>
  );
}
