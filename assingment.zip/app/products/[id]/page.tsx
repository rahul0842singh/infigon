import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";
import { FavoriteDetails } from "./ui/FavoriteDetails";
import { getProduct } from "@/lib/api";
import { formatPrice, safeNumber } from "@/lib/utils";

type Params = { id: string };

export default async function ProductDetailsPage({
  params,
}: {
  params: Params;
}) {
  const id = safeNumber(params.id);
  if (!id) notFound();

  const product = await getProduct(id).catch(() => null);
  if (!product) notFound();

  return (
    <AppShell
      title="Product Explorer"
      subtitle="Product details"
      right={
        <Link href="/products">
          <Button variant="ghost" size="sm">
            ← Back
          </Button>
        </Link>
      }
    >
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="overflow-hidden rounded-2xl border border-black/10 bg-white/70 shadow-soft backdrop-blur dark:border-white/10 dark:bg-white/10">
          <div className="relative aspect-square w-full bg-white/60 dark:bg-white/5">
            <Image
              src={product.image}
              alt={product.title}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-contain p-10"
              priority
            />
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="space-y-2">
              <Badge>{product.category}</Badge>
              <h1 className="text-xl font-semibold tracking-tight">
                {product.title}
              </h1>
              <div className="text-lg font-semibold">
                {formatPrice(product.price)}
              </div>
            </div>

            <FavoriteDetails productId={product.id} />
          </div>

          <div className="rounded-2xl border border-black/10 bg-white/60 p-4 text-sm leading-relaxed text-black/80 shadow-soft backdrop-blur dark:border-white/10 dark:bg-white/10 dark:text-white/80">
            {product.description}
          </div>

          <div className="flex flex-wrap gap-2">
            <Link href="/products">
              <Button>Browse more</Button>
            </Link>
            <a
              href="https://fakestoreapi.com/"
              target="_blank"
              rel="noreferrer"
              className="inline-flex"
            >
              <Button variant="ghost">API Source</Button>
            </a>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
